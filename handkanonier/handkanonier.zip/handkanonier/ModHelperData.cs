namespace handkanonier;

public static class ModHelperData
{
    public const string Version = "35";
    public const string Name = "handkanonier";

    public const string Description = "thanks to david for the concept";
 public const string SubPath = "handkanonier";
 public const string DllName = "handkanonier.dll";
 public const string WorksOnVersion = "34";

    public const string RepoOwner = "Timotheeee";
    public const string RepoName = "btd6_mods";
}
